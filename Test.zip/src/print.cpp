#include <iostream>
using namespace std;
int test(int x)
{
    cout<<"Hello World"<< x << endl;
    return 0;
}