#include <iostream>
#include "../include/print.h"
#include "../src/hello.cpp"
using namespace std;
int main()
{
    Hello H1;
    test(3);
    H1.print1();
    cout<<"Hello World";
    return 0;
}

